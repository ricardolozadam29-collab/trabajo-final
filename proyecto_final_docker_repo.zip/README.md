# Proyecto Final Docker

Este repositorio contiene el proyecto final del laboratorio práctico:
**Instalación de Docker e Implementación de Sistemas Operativos Linux**.

## Contenido del repositorio
- Archivos del proyecto original.
- APP.7z (en caso de necesitar extracción manual).
- Instrucciones de uso.
- Estructura lista para subir a GitHub.

## Cómo subir este proyecto a GitHub
1. Crea un repositorio vacío en GitHub llamado:
   **proyecto-final-docker**

2. En tu computadora, ejecuta:

```bash
git init
git add .
git commit -m "Proyecto Final Docker"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/proyecto-final-docker.git
git push -u origin main
```

## Notas
- Si el archivo APP.7z no se extrajo automáticamente, descomprímelo localmente y colócalo dentro de la carpeta.
